/**
 * Every animal of the game (data only): where it lives, how it behaves, how fast it is.
 * AnimalModel builds the body, AnimalManager spawns and drives them.
 */
export type Species =
  // farm and village
  | 'cow' | 'buffalo' | 'goat' | 'sheep' | 'horse' | 'dog' | 'cat' | 'chicken' | 'duck'
  // wild herbivores
  | 'deer' | 'boar' | 'rabbit' | 'elephant' | 'zebra' | 'giraffe' | 'rhino' | 'hippo'
  // predators and omnivores
  | 'tiger' | 'lion' | 'leopard' | 'wolf' | 'fox' | 'bear'
  // birds, reptiles, sea
  | 'peacock' | 'crocodile' | 'dolphin';

export type Role =
  /** Runs from predators and from the player (deer, zebra, rabbit, boar). */
  | 'prey'
  /** Hunts the species in `hunts`. */
  | 'predator'
  /** Calm big animals: they only step aside (elephant, giraffe, rhino, bear). */
  | 'grazer'
  /** Farm and village animals: stay near their home, hardly afraid of the player. */
  | 'domestic'
  /** Small birds that walk (chicken, duck, peacock). */
  | 'bird'
  /** Lies about near the water and slides in when disturbed (crocodile, hippo). */
  | 'amphibian'
  /** Lives in open water only. */
  | 'marine';

export interface SpeciesDef {
  id: Species;
  bn: string;
  role: Role;
  /** Herd / flock size (inclusive). */
  group: [number, number];
  /** Walking and running speed (m/s). */
  walk: number;
  run: number;
  /** Individual size variation (1 = the model's size). */
  size: [number, number];
  /** The player this close (m) makes it step aside / run. */
  shy: number;
  /** Maximum alive at once. */
  cap: number;
  /** Typical walking distance between two resting places (m). */
  roam: number;
  /** Deepest water it can stand / swim in (m). Land-only animals have no value. */
  swim?: number;
  /** Spawns in or beside water. */
  needsWater?: boolean;
  /** Species a predator goes after. */
  hunts?: Species[];
  /** Fraction of the time it spends resting / grazing instead of walking (0..1). */
  idle: number;
}

const D = (d: SpeciesDef): SpeciesDef => d;

export const SPECIES: Record<Species, SpeciesDef> = {
  cow: D({ id: 'cow', bn: 'গরু', role: 'domestic', group: [3, 7], walk: 0.9, run: 5.5, size: [0.92, 1.08], shy: 5, cap: 14, roam: 30, idle: 0.6 }),
  buffalo: D({ id: 'buffalo', bn: 'মহিষ', role: 'domestic', group: [2, 5], walk: 0.9, run: 6, size: [0.95, 1.1], shy: 6, cap: 9, roam: 30, swim: 1.6, idle: 0.6 }),
  goat: D({ id: 'goat', bn: 'ছাগল', role: 'domestic', group: [3, 7], walk: 1.1, run: 7, size: [0.85, 1.1], shy: 5, cap: 14, roam: 28, idle: 0.5 }),
  sheep: D({ id: 'sheep', bn: 'ভেড়া', role: 'domestic', group: [4, 9], walk: 1.0, run: 7.5, size: [0.9, 1.1], shy: 7, cap: 14, roam: 28, idle: 0.55 }),
  horse: D({ id: 'horse', bn: 'ঘোড়া', role: 'domestic', group: [1, 3], walk: 1.5, run: 14, size: [0.95, 1.08], shy: 8, cap: 6, roam: 40, idle: 0.5 }),
  dog: D({ id: 'dog', bn: 'কুকুর', role: 'domestic', group: [1, 3], walk: 1.4, run: 9, size: [0.8, 1.15], shy: 3, cap: 8, roam: 45, idle: 0.35 }),
  cat: D({ id: 'cat', bn: 'বিড়াল', role: 'domestic', group: [1, 2], walk: 1.0, run: 7, size: [0.9, 1.1], shy: 6, cap: 8, roam: 20, idle: 0.6 }),
  chicken: D({ id: 'chicken', bn: 'মুরগি', role: 'bird', group: [4, 9], walk: 0.6, run: 3.6, size: [0.9, 1.1], shy: 5, cap: 16, roam: 14, idle: 0.55 }),
  duck: D({ id: 'duck', bn: 'হাঁস', role: 'bird', group: [4, 10], walk: 0.6, run: 3.2, size: [0.9, 1.1], shy: 6, cap: 16, roam: 25, swim: 3, needsWater: true, idle: 0.4 }),
  deer: D({ id: 'deer', bn: 'হরিণ', role: 'prey', group: [4, 6], walk: 1.5, run: 13.5, size: [0.9, 1.1], shy: 28, cap: 16, roam: 40, idle: 0.4 }),
  boar: D({ id: 'boar', bn: 'বন্য শূকর', role: 'prey', group: [3, 6], walk: 1.3, run: 11, size: [0.9, 1.1], shy: 20, cap: 10, roam: 35, idle: 0.5 }),
  rabbit: D({ id: 'rabbit', bn: 'খরগোশ', role: 'prey', group: [2, 4], walk: 0.9, run: 11, size: [0.9, 1.1], shy: 14, cap: 10, roam: 14, idle: 0.6 }),
  elephant: D({ id: 'elephant', bn: 'হাতি', role: 'grazer', group: [2, 5], walk: 1.3, run: 6.5, size: [0.9, 1.08], shy: 14, cap: 7, roam: 50, swim: 2.2, idle: 0.45 }),
  zebra: D({ id: 'zebra', bn: 'জেব্রা', role: 'prey', group: [4, 8], walk: 1.5, run: 15, size: [0.95, 1.06], shy: 30, cap: 14, roam: 45, idle: 0.4 }),
  giraffe: D({ id: 'giraffe', bn: 'জিরাফ', role: 'grazer', group: [2, 4], walk: 1.5, run: 12, size: [0.92, 1.08], shy: 22, cap: 7, roam: 45, idle: 0.45 }),
  rhino: D({ id: 'rhino', bn: 'গণ্ডার', role: 'grazer', group: [1, 2], walk: 1.1, run: 9, size: [0.95, 1.06], shy: 16, cap: 5, roam: 35, idle: 0.55 }),
  hippo: D({ id: 'hippo', bn: 'জলহস্তী', role: 'amphibian', group: [1, 3], walk: 0.9, run: 5, size: [0.95, 1.06], shy: 12, cap: 5, roam: 18, swim: 3.2, needsWater: true, idle: 0.7 }),
  tiger: D({ id: 'tiger', bn: 'বাঘ', role: 'predator', group: [1, 1], walk: 1.7, run: 17, size: [0.95, 1.12], shy: 32, cap: 3, roam: 50, hunts: ['deer', 'boar'], idle: 0.5 }),
  lion: D({ id: 'lion', bn: 'সিংহ', role: 'predator', group: [1, 1], walk: 1.7, run: 17.5, size: [0.95, 1.12], shy: 32, cap: 3, roam: 50, hunts: ['zebra', 'deer'], idle: 0.5 }),
  leopard: D({ id: 'leopard', bn: 'চিতাবাঘ', role: 'predator', group: [1, 1], walk: 1.5, run: 16, size: [0.95, 1.1], shy: 32, cap: 3, roam: 45, hunts: ['deer', 'goat', 'rabbit'], idle: 0.5 }),
  wolf: D({ id: 'wolf', bn: 'নেকড়ে', role: 'predator', group: [1, 1], walk: 1.6, run: 15, size: [0.95, 1.1], shy: 30, cap: 3, roam: 50, hunts: ['deer', 'goat', 'sheep', 'rabbit'], idle: 0.45 }),
  fox: D({ id: 'fox', bn: 'শিয়াল', role: 'predator', group: [1, 1], walk: 1.4, run: 12, size: [0.92, 1.1], shy: 25, cap: 3, roam: 40, hunts: ['rabbit', 'chicken'], idle: 0.45 }),
  bear: D({ id: 'bear', bn: 'ভালুক', role: 'grazer', group: [1, 2], walk: 1.2, run: 9, size: [0.95, 1.1], shy: 30, cap: 3, roam: 40, idle: 0.5 }),
  peacock: D({ id: 'peacock', bn: 'ময়ূর', role: 'bird', group: [2, 4], walk: 0.8, run: 5, size: [0.95, 1.05], shy: 9, cap: 7, roam: 20, idle: 0.55 }),
  crocodile: D({ id: 'crocodile', bn: 'কুমির', role: 'amphibian', group: [1, 2], walk: 0.8, run: 4, size: [0.85, 1.15], shy: 13, cap: 5, roam: 15, swim: 4, needsWater: true, idle: 0.75 }),
  dolphin: D({ id: 'dolphin', bn: 'ডলফিন', role: 'marine', group: [2, 4], walk: 3, run: 8, size: [0.9, 1.1], shy: 0, cap: 8, roam: 80, swim: 99, idle: 0 }),
};

export const ALL_SPECIES = Object.keys(SPECIES) as Species[];

/**
 * Where an animal lives = the REAL land cover the player sees, not the abstract zone map (AnimalManager.habitatAt decides):
 *  farm     - open land beside the real crop fields (FarmFields), never on the crops
 *  village  - around the real village houses (mud huts, bamboo huts, tin houses ...)
 *  forest   - where the forest noise really grows dense trees (the same field the tree placer uses)
 *  mountain - high bare ground above the farms
 *  wetland  - the edge of a real river / lake / pond
 *  park     - the green park zones of the city
 *  safari   - the safari park (L key): only the park cells inside its circle; African animals never leave it
 */
export type HabitatKey = 'farm' | 'village' | 'forest' | 'mountain' | 'wetland' | 'park' | 'safari';

/** Relative weights per habitat: a bigger number = commoner there. Built-up land (city, industry, airport, port) has no wildlife at all. */
export const HABITAT: Partial<Record<HabitatKey, Partial<Record<Species, number>>>> = {
  farm: { cow: 4, buffalo: 2, goat: 3, sheep: 2, horse: 1.2, dog: 0.6, rabbit: 2, duck: 1, peacock: 0.5, deer: 0.5 },
  village: { cow: 3, goat: 3, chicken: 5, dog: 2, cat: 2.5, duck: 2, sheep: 1, buffalo: 1 },
  forest: { deer: 4, boar: 3, elephant: 1.5, bear: 0.8, peacock: 2, rabbit: 1 },
  mountain: { goat: 3, deer: 2, boar: 1, bear: 1.2, sheep: 1 },
  wetland: { buffalo: 2, crocodile: 2.5, hippo: 1.2, duck: 3.5 },
  park: { deer: 3, rabbit: 2, duck: 3, peacock: 1.5, horse: 0.6, dog: 0.6, cat: 0.6 },
  safari: { zebra: 4, giraffe: 2.5, elephant: 1.6, rhino: 1.4, hippo: 1.2, deer: 1.2, boar: 0.6 },
};

/**
 * DENSE JUNGLE (ghono jongol, where Config.vegetation denseAt >= 0.45): the forest table with more of everything wild. Used instead of HABITAT.forest there; the
 * predators (tiger, leopard, wolf, fox) come with the herds they hunt, more often and more of them (AnimalManager.jungleNear).
 */
export const JUNGLE_HABITAT: Partial<Record<Species, number>> = { deer: 4, boar: 3.5, elephant: 2, bear: 1.4, peacock: 3, rabbit: 2.5 };

/** Where a predator may live. */
export const PREDATOR_ZONES: Partial<Record<Species, readonly HabitatKey[]>> = {
  tiger: ['forest', 'mountain', 'wetland'],
  lion: ['safari'],
  leopard: ['forest', 'mountain', 'safari'],
  wolf: ['mountain', 'forest'],
  fox: ['farm', 'forest', 'village', 'park'],
};

/** Every habitat a species may stand in (a walking animal that reaches the edge of these turns back). */
export const HABITATS_OF: Record<Species, ReadonlySet<HabitatKey>> = (() => {
  const out = {} as Record<Species, Set<HabitatKey>>;
  for (const sp of Object.keys(SPECIES) as Species[]) out[sp] = new Set<HabitatKey>();
  for (const k of Object.keys(HABITAT) as HabitatKey[]) for (const sp of Object.keys(HABITAT[k] ?? {}) as Species[]) if ((HABITAT[k]?.[sp] ?? 0) > 0) out[sp].add(k);
  for (const sp of Object.keys(PREDATOR_ZONES) as Species[]) for (const k of PREDATOR_ZONES[sp] ?? []) out[sp].add(k);
  return out;
})();

/** The prey animals (and domestic ones) that predators attack. */
export const isPredator = (sp: Species): boolean => SPECIES[sp].role === 'predator';
